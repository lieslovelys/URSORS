<?php 
include 'configs/home_header.php';
?>


<?php 
if ($_SESSION['role'] == 'admin') { ?>
    <div class="container">
    <a href="ce_elect.html" ><span class="material-icons back-button">arrow_back</span></a>
        <div class="flashcard-container">
            <a href="/Admin/BackEnd/home.php?section=Bachelor+of+Science+in+Civil+Engineering&sub_section=Civil+Engineering+Electives&nested_sub_section=Earthquake+Engineering&deep_sub_section=General" class="flashcard">
                <div class="flashcard-content">
                    <span class="material-icons flashcard-icon">library_books</span>
                    <h3>General</h3>
                    <p>Computer Engineering</p>
                </div>
            </a>
            <a href="" class="flashcard">
                <div class="flashcard-content">
                    <span class="material-icons flashcard-icon">library_books</span>
                    <h3>...</h3>
                    <p>...</p>
                </div>
            </a>
        </div>

    </div>

<?php } elseif ($_SESSION['role'] == 'teacher'){ ?>

    <div class="container">
    <a href="ce_elect.html" ><span class="material-icons back-button">arrow_back</span></a>
        <div class="flashcard-container">
            <a href="/Admin/BackEnd/teacher_feed.php?section=Bachelor+of+Science+in+Civil+Engineering&sub_section=Civil+Engineering+Electives&nested_sub_section=Earthquake+Engineering&deep_sub_section=General" class="flashcard">
                <div class="flashcard-content">
                    <span class="material-icons flashcard-icon">library_books</span>
                    <h3>General</h3>
                    <p>Computer Engineering</p>
                </div>
            </a>
            <a href="" class="flashcard">
                <div class="flashcard-content">
                    <span class="material-icons flashcard-icon">library_books</span>
                    <h3>...</h3>
                    <p>...</p>
                </div>
            </a>
        </div>

    </div>

<?php } else { ?>

    <div class="container">
    <a href="ce_elect.html" ><span class="material-icons back-button">arrow_back</span></a>
        <div class="flashcard-container">
            <a href="/Admin/BackEnd/student_feed.php?section=Bachelor+of+Science+in+Civil+Engineering&sub_section=Civil+Engineering+Electives&nested_sub_section=Earthquake+Engineering&deep_sub_section=General" class="flashcard">
                <div class="flashcard-content">
                    <span class="material-icons flashcard-icon">library_books</span>
                    <h3>General</h3>
                    <p>Computer Engineering</p>
                </div>
            </a>
            <a href="" class="flashcard">
                <div class="flashcard-content">
                    <span class="material-icons flashcard-icon">library_books</span>
                    <h3>...</h3>
                    <p>...</p>
                </div>
            </a>
        </div>

    </div>

<?php } ?>



<?php 
include 'configs/home_footer.php';
?>