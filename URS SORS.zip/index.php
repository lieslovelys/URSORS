<?php
session_start();
include 'Admin/BackEnd/config.php';
$sql = "SELECT id, password, role, is_approved FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>URS S.O.R.S</title>
    <link rel="icon" type="image/ico" href="/img/title_icon.png">
    <link rel="stylesheet" href="index.css">
    <style>

    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href="index.php"><img src="/img/sors_logo.png" alt=""></a>
    </nav>

    <!-- Main Content -->
    <div class="home-content">
        <h1>University of Rizal System <br> Student Online Resource Site</h1>
        <p>Your new online source platform. Connect with students, share your thoughts, and stay educated.</p>

        <?php if (isset($_SESSION['username'])): ?>
            <p>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
            <?php if ($_SESSION['role'] == 'admin'){?>
                <p><a href="/Admin/BackEnd/admin_home.php" class="button">Proceed to Home</a></p>
            <?php }else{?>
                <p><a href="/Admin/FrontEnd/home_sections/welcome.php" class="button">Proceed to Home</a></p>
                <?php }?>    
        <?php else: ?>
            <p><a href="/Admin/FrontEnd/login.html" class="button">Login</a> <a href="/Admin/FrontEnd/register.html" class="button">Sign Up</a></p>
        <?php endif; ?>
    </div>

</body>
</html>
